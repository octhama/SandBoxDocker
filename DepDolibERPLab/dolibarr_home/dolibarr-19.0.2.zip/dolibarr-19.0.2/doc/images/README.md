# README (English)
--------------------------------


* Screen captures and icons are Dolibarr contributions


* Most logos were created by Dolibarr developers. You may find sources of them on:

https://github.com/Dolibarr/foundation



# LICENCE OF IMAGE RESOURCES
--------------------------------

* All image resources (except dolihelp.ico and doliadmin.ico) in this directory are distributed under licence CC BY-SA

List of icons from http://led24.de/iconset/ are:
- doliadmin.ico
- dolihelp.ico

This is original README file for the package with this 2 images:
You can do whatever you want with these icons (use on web or in desktop applications) as long as you don’t pass them off as your own and remove this readme file. A credit statement and a link back to
http://led24.de/iconset/ or http://led24.de/ would be appreciated.
