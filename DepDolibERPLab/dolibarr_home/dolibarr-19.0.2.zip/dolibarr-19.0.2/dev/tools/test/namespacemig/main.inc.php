<?php
/*spl_autoload_register(function ($class_name) {
	//var_dump('class='.$class_name);
	require $class_name;
});
*/
